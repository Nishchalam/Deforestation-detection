"""
Deforestation Detection package.
"""
from .dataset import EuroSATDataset
from .dataloader import create_dataloaders